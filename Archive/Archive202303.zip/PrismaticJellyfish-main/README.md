# PrismaticJellyfish
Open Source GUI and App Creator. Web Browser Based. Uses Blockly.




***
Otter Lake, the website where Prismatic Jellyfish Tools will be available to use through the web or locally if downloaded and run through a local web browser 
(File://path/to/index.html will suffice, no need for localhost).


Link to OtterLake GitHub.com preview:

https://htmlpreview.github.io/?https://github.com/Lafender/PrismaticJellyfish/blob/main/OtterLake20230308/OtterLakeHome2.html


Preview ScreenCapture:

![screenshot-2023030221533](https://user-images.githubusercontent.com/11316682/222779150-d1fcdc01-afc2-45bd-b671-25537dea5acc.png)

***
