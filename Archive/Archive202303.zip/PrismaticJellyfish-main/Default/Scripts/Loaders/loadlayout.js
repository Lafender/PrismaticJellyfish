function loadLayout(elem, layout)
{
    elem.innerHTML = '<script type="text/javascript" src="./Default/Scripts/loadlayout.js"></script>' ;
    elem.style = layout;
}
