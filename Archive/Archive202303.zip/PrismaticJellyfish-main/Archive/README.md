# Archive

***
**previous versions** of *Prismatic Jellyfish* and Files/Plans/Documents:

**2022**
-
-
-

**2023**
-
-
-


**Prismatic History** :
Prismatic Jellyfish started as an idea.
After much struggle, a method was determined.
A better way.

While the method is recorded and input, you are welcome to participate and contribute.
No contribution is nessassary.
Participation and feedback is welcome. Please stay positive and kind.

I hope everyone who tries Prismatic feels inspired.



***
