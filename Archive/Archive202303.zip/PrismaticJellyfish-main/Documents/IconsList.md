# Prismatic Jellyfish

…

## Icon List

…

### Document Updates

…

|
 |
 |
| --- | --- |
| Document Created | January 15th 2023, 7:05 pm |
|
 |
 |

…

…

…

### Icon List

…

January 15th 2023

7:15 pm

…

| Index | Name
 | Path | Filename

 | Thumbnail
 | Description
 | Links |
| --- | --- | --- | --- | --- | --- | --- |
| 0001 | Hamburger |
 |
 |
 |
 |
 |
| 0002 | Ellipses |
 |
 |
 |
 |
 |
| 0003 | Tab |
 |
 |
 |
 |
 |
| 0004 | Plus |
 |
 |
 |
 |
 |
| 0005 | Dash |
 |
 |
 |
 |
 |
| 0006 | Star |
 |
 |
 |
 |
 |
| 0007 | Slash |
 |
 |
 |
 |
 |
| 0008 | Equals |
 |
 |
 |
 |
 |
| 0009 | x |
 |
 |
 |
 |
 |
| 0010 | y |
 |
 |
 |
 |
 |
| 0011 | z |
 |
 |
 |
 |
 |
| 0012 | Greater |
 |
 |
 |
 |
 |
| 0013 | Less |
 |
 |
 |
 |
 |
| 0014 | v |
 |
 |
 |
 |
 |
| 0015 | Hat |
 |
 |
 |
 |
 |
| 0016 | Dollar |
 |
 |
 |
 |
 |
| 0017 | Hashtag |
 |
 |
 |
 |
 |
| 0018 | At |
 |
 |
 |
 |
 |
| 0019 | Bang |
 |
 |
 |
 |
 |
| 0020 | Question |
 |
 |
 |
 |
 |
| 0021 | Underscore |
 |
 |
 |
 |
 |
| 0022 | And |
 |
 |
 |
 |
 |
| 0023 | Quote |
 |
 |
 |
 |
 |
| 0024 | Left Bracket |
 |
 |
 |
 |
 |
| 0025 | Right Bracket |
 |
 |
 |
 |
 |
| 0026 | Left Square Bracket |
 |
 |
 |
 |
 |
| 0027 | Right Square Bracket |
 |
 |
 |
 |
 |
| 0028 | Left Curly Bracket |
 |
 |
 |
 |
 |
| 0029 | Right Curly Bracket |
 |
 |
 |
 |
 |
| 0030 | Back Slash |
 |
 |
 |
 |
 |
| 0031 | Tilde |
 |
 |
 |
 |
 |
| 0032 | Or |
 |
 |
 |
 |
 |
| 0033 | Check |
 |
 |
 |
 |
 |
| 0034 | Delta |
 |
 |
 |
 |
 |
| 0035 | Paragraph |
 |
 |
 |
 |
 |
| 0036 | Dot |
 |
 |
 |
 |
 |
| 0037 | New Line |
 |
 |
 |
 |
 |
| 0038 | Space |
 |
 |
 |
 |
 |
| 0039 | Arrow |
 |
 |
 |
 |
 |
|
 | Square |
 |
 |
 |
 |
 |
|
 | Circle |
 |
 |
 |
 |
 |
|
 | Ellipse |
 |
 |
 |
 |
 |
|
 | Triangle |
 |
 |
 |
 |
 |
|
 | Quadrilateral |
 |
 |
 |
 |
 |
|
 | Heart |
 |
 |
 |
 |
 |
|
 | Fire |
 |
 |
 |
 |
 |
|
 | Droplet |
 |
 |
 |
 |
 |
|
 | Sun |
 |
 |
 |
 |
 |
|
 | Moon |
 |
 |
 |
 |
 |
|
 | Star |
 |
 |
 |
 |
 |
|
 | Earth |
 |
 |
 |
 |
 |
|
 | Snowflake |
 |
 |
 |
 |
 |
|
 | Lightning |
 |
 |
 |
 |
 |
|
 | Cube |
 |
 |
 |
 |
 |
|
 | Floppy Disk |
 |
 |
 |
 |
 |
| 0040 | Disk |
 |
 |
 |
 |
 |
| 0041 | Path |
 |
 |
 |
 |
 |
| 0042 | Tree |
 |
 |
 |
 |
 |
| 0043 | List |
 |
 |
 |
 |
 |
|
 | Folder |
 |
 |
 |
 |
 |
|
 | Table |
 |
 |
 |
 |
 |
|
 | Image |
 |
 |
 |
 |
 |
|
 | Scissors |
 |
 |
 |
 |
 |
|
 | Clipboard |
 |
 |
 |
 |
 |
|
 | Magnifier |
 |
 |
 |
 |
 |
|
 | Crop |
 |
 |
 |
 |
 |
|
 | Pen |
 |
 |
 |
 |
 |
|
 | Letter |
 |
 |
 |
 |
 |
|
 | USB |
 |
 |
 |
 |
 |
|
 | Git |
 |
 |
 |
 |
 |
|
 | Blockly |
 |
 |
 |
 |
 |
| 0044 | Fish |
 |
 |
 |
 |
 |
| 0045 | Squid |
 |
 |
 |
 |
 |
| 0046 | Octopus |
 |
 |
 |
 |
 |
| 0047 | Crab |
 |
 |
 |
 |
 |
| 0048 | Lobster |
 |
 |
 |
 |
 |
| 0049 | Jelly |
 |
 |
 |
 |
 |
| 0050 | Shark |
 |
 |
 |
 |
 |
| 0051 | Frog |
 |
 |
 |
 |
 |
| 0052 | Gecko |
 |
 |
 |
 |
 |
| 0053 | Dragon |
 |
 |
 |
 |
 |
| 0054 | Snake |
 |
 |
 |
 |
 |
| 0055 | Gator |
 |
 |
 |
 |
 |
| 0056 | Turtle |
 |
 |
 |
 |
 |
| 0057 | Duck |
 |
 |
 |
 |
 |
| 0058 | Goose |
 |
 |
 |
 |
 |
|
 | Penguin |
 |
 |
 |
 |
 |
|
 | Seal |
 |
 |
 |
 |
 |
|
 | Dolphin |
 |
 |
 |
 |
 |
|
 | Tiger |
 |
 |
 |
 |
 |
|
 | Fox |
 |
 |
 |
 |
 |
|
 | Wolf |
 |
 |
 |
 |
 |
|
 | Hedgehog |
 |
 |
 |
 |
 |
|
 | Otter |
 |
 |
 |
 |
 |
|
 | Racoon |
 |
 |
 |
 |
 |
|
 | Skunk |
 |
 |
 |
 |
 |
|
 | Rabbit |
 |
 |
 |
 |
 |
|
 | Rat |
 |
 |
 |
 |
 |
|
 | Squirrel |
 |
 |
 |
 |
 |
|
 | Moose |
 |
 |
 |
 |
 |
|
 | Cow |
 |
 |
 |
 |
 |
|
 | Elephant |
 |
 |
 |
 |
 |
|
 | Alpaca |
 |
 |
 |
 |
 |
|
 | Llama |
 |
 |
 |
 |
 |
|
 | Deer |
 |
 |
 |
 |
 |
|
 | Goat |
 |
 |
 |
 |
 |
|
 | Ram |
 |
 |
 |
 |
 |
|
 | Sheep |
 |
 |
 |
 |
 |
|
 | Cat |
 |
 |
 |
 |
 |
|
 | Dog |
 |
 |
 |
 |
 |
|
 | Horse |
 |
 |
 |
 |
 |

…

…

…

Script for automatically updating file (this word document, or JSON)

Script for automatically creating a thumbnail (resizer) (cropper) (alignment selector)

…

### Templates

…

Table

Name

Thumbnail

Filename

Path

Description

…
